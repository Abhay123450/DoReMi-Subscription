const categories = [
    "MUSIC", "VIDEO", "PODCAST"
]