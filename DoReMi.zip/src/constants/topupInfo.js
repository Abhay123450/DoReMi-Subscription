const topupInfo = {
    FOUR_DEVICE: {
        COST: 50,
        DURATION: 1,
        MAX_DEVICES: 4
    },
    TEN_DEVICE: {
        COST: 100,
        DURATION: 1,
        MAX_DEVICES: 10
    }
}

module.exports = { topupInfo }