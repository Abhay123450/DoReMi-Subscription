const plans = ["FREE", "PERSONAL", "PREMIUM"];

module.exports = { plans };