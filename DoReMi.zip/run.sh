#!/bin/bash

npm ci --silent
npm start --silent sample_input/input1.txt
